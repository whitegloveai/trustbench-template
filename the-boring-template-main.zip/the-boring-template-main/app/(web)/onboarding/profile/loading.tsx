import { CreateProfileFormSkeleton } from "@/components/forms/create-profile-form"

export default function OnboardingProfileLoading() {
  return <CreateProfileFormSkeleton />
}
